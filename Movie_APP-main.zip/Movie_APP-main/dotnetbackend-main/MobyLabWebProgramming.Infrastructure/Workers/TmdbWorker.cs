﻿using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MobyLabWebProgramming.Core.Configuration;
using MobyLabWebProgramming.Core.Entities;
using MobyLabWebProgramming.Core.Specifications;
using MobyLabWebProgramming.Infrastructure.Database;
using MobyLabWebProgramming.Infrastructure.Repositories.Interfaces;

namespace MobyLabWebProgramming.Infrastructure.Workers;

/// <summary>
///  Worker care – la fiecare <see cref="RunInterval"/> – importă pagini din TMDB,
///  adaugă filmele inexistente și, dacă e nevoie, genurile lipsă.
/// </summary>
public sealed class TmdbImportWorker(
        ILogger<TmdbImportWorker> logger,
        IServiceScopeFactory      scopeFactory,
        IOptions<TMDBConfiguration> tmdbCfg)
    : BackgroundService
{
    private const int _pagesToFetchPerCycle = 1;
    
    private       int _currentPage = 1;

    protected override async Task ExecuteAsync(CancellationToken stopToken)
    {
        while (!stopToken.IsCancellationRequested)
        {
            await using var scope = scopeFactory.CreateAsyncScope();
            var repo = scope.ServiceProvider.GetRequiredService<IRepository<WebAppDatabaseContext>>();
            using    var client = new HttpClient();

            for (var i = 0; i < _pagesToFetchPerCycle && !stopToken.IsCancellationRequested; i++)
            {
                var page = _currentPage + i;
                var url  = $"{tmdbCfg.Value.BaseUrl}/movie/popular?api_key={tmdbCfg.Value.ApiKey}&page={page}";

                logger.LogInformation("[TMDB Worker] Fetching page {Page}", page);
                var response = await client.GetAsync(url, stopToken);

                if (!response.IsSuccessStatusCode)
                {
                    logger.LogWarning("[TMDB Worker] TMDB returned {StatusCode} for page {Page}",
                                      response.StatusCode, page);
                    continue;
                }

                using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync(stopToken));
                var results   = doc.RootElement.GetProperty("results").EnumerateArray();
                var addedCnt  = 0;

                foreach (var m in results)
                {
                    var title       = m.GetProperty("title").GetString()!;
                    var releaseText = m.GetProperty("release_date").GetString() ?? string.Empty;
                    if (!int.TryParse(releaseText[..4], out var year)) continue;

                    //  Evităm duplicatele
                    if (await repo.GetAsync(new MovieByTitleAndYearSpec(title, year), stopToken) is not null)
                        continue;

                    var movie = new Movie
                    {
                        Title       = title,
                        Year        = year,
                        Description = m.GetProperty("overview").GetString(),
                        PosterUrl   = m.TryGetProperty("poster_path", out var p) && !p.GetString()!.Equals("null", StringComparison.OrdinalIgnoreCase)
                                      ? $"https://image.tmdb.org/t/p/w500{p.GetString()}"
                                      : null
                    };

                    await repo.AddAsync(movie, stopToken);
                    addedCnt++;

                    //  Genurile
                    foreach (var gid in m.GetProperty("genre_ids").EnumerateArray().Select(e => e.GetInt32()))
                    {
                        var gName = GenreIdToName(gid);
                        if (gName is null) continue;

                        var genre = await repo.GetAsync(new GenreSpec(gName), stopToken)
                                   ?? await repo.AddAsync(new Genre { Name = gName }, stopToken);

                        await repo.AddAsync(new MovieGenre { MovieId = movie.Id, GenreId = genre.Id }, stopToken);
                    }
                }

                logger.LogInformation("[TMDB Worker] Added {Count} movies from page {Page}", addedCnt, page);
            }

            _currentPage += _pagesToFetchPerCycle;
            
            await Task.Delay(TimeSpan.FromMinutes(5), stopToken);
        }
    }

    private static string? GenreIdToName(int id) => id switch
    {
        28      => "Action",
        12      => "Adventure",
        16      => "Animation",
        35      => "Comedy",
        80      => "Crime",
        99      => "Documentary",
        18      => "Drama",
        10751   => "Family",
        14      => "Fantasy",
        36      => "History",
        27      => "Horror",
        10402   => "Music",
        9648    => "Mystery",
        10749   => "Romance",
        878     => "Science Fiction",
        10770   => "TV Movie",
        53      => "Thriller",
        10752   => "War",
        37      => "Western",
        _       => null
    };
}
