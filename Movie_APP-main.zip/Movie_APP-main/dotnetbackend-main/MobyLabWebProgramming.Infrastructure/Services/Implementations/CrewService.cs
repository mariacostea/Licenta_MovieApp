﻿namespace MobyLabWebProgramming.Infrastructure.Services.Implementations;

public class CrewService : ICrewService
{
    private readonly IRepository<WebAppDatabaseContext> _repo;

    public CrewService(IRepository<WebAppDatabaseContext> repo) => _repo = repo;

    public async Task<ServiceResponse> AddCrew(CrewDTO dto, CancellationToken ct = default)
    {
        var crew = new Crew
        {
            FirstName = dto.FirstName,
            LastName = dto.LastName,
            ImageUrl = dto.ImageUrl,
            Birthday = dto.Birthday
        };

        await _repo.AddAsync(crew, ct);
        return ServiceResponse.ForSuccess();
    }

    public async Task<ServiceResponse<List<CrewDTO>>> GetAllCrew(CancellationToken ct = default)
    {
        var result = await _repo.ListAsync<Crew>(c => true, ct);

        return ServiceResponse<List<CrewDTO>>.ForSuccess(result
            .Select(c => new CrewDTO
            {
                Id = c.Id,
                FirstName = c.FirstName,
                LastName = c.LastName,
                ImageUrl = c.ImageUrl,
                Birthday = c.Birthday
            }).ToList());
    }

    public async Task<ServiceResponse> AddCrewToMovie(Guid movieId, MovieCrewDTO dto, CancellationToken ct = default)
    {
        var link = new MovieCrew
        {
            MovieId = movieId,
            CrewId = dto.CrewId,
            PersonType = dto.PersonType
        };

        await _repo.AddAsync(link, ct);
        return ServiceResponse.ForSuccess();
    }

    public async Task<ServiceResponse<List<CrewDTO>>> GetCrewForMovie(Guid movieId, CancellationToken ct = default)
    {
        var result = await _repo.ListAsync<MovieCrew>(
            m => m.MovieId == movieId,
            includes: new[] { "Crew" },
            ct);

        var crewList = result.Select(mc => new CrewDTO
        {
            Id = mc.Crew.Id,
            FirstName = mc.Crew.FirstName,
            LastName = mc.Crew.LastName,
            ImageUrl = mc.Crew.ImageUrl,
            Birthday = mc.Crew.Birthday
        }).ToList();

        return ServiceResponse<List<CrewDTO>>.ForSuccess(crewList);
    }
}
