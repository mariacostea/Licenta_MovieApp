﻿namespace MobyLabWebProgramming.Core.DataTransferObjects;

public class MovieYearDTO
{
    public int Year { get; set; }
}