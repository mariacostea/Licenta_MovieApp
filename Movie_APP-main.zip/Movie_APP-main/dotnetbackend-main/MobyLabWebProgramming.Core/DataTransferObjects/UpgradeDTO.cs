﻿namespace MobyLabWebProgramming.Core.DataTransferObjects;

public class UpgradeDTO
{
    public string Email { get; set; }
    public string Code { get; set; }
}