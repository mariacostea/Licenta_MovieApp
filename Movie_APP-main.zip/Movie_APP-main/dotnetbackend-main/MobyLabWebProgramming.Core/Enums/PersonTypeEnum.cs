﻿namespace MobyLabWebProgramming.Core.Enums;

public enum PersonTypeEnum
{
    Actor   = 0,
    Director = 1,
}