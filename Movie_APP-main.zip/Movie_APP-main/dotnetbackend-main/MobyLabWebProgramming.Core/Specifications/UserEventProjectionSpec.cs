﻿namespace MobyLabWebProgramming.Core.Specifications;

public class UserEventProjectionSpec
{
    
}