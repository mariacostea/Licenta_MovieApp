﻿import React from 'react';

const Feed: React.FC = () => {
    return (
        <div>
            <h2>📰 Feed Page</h2>
            <p>This is the Feed section.</p>
        </div>
    );
};

export default Feed;
