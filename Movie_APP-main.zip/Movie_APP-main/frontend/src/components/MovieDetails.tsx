﻿import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { MovieCardProps } from "./MovieCard";

interface Review {
    id: string;
    content: string;
    rating: number;
    userId: string;
}

const MovieDetails: React.FC = () => {
    const { id } = useParams();
    const [movie, setMovie] = useState<MovieCardProps & { description: string } | null>(null);
    const [loading, setLoading] = useState(true);
    const [reviews, setReviews] = useState<Review[]>([]);
    const [reviewText, setReviewText] = useState("");
    const [reviewRating, setReviewRating] = useState(1);

    useEffect(() => {
        const fetchMovie = async () => {
            try {
                const res = await fetch(`http://localhost:5000/api/movie/${id}`);
                const json = await res.json();
                setMovie(json.result);
            } catch (err) {
                console.error("Error loading movie details:", err);
            } finally {
                setLoading(false);
            }
        };

        fetchMovie();
    }, [id]);

    useEffect(() => {
        const fetchReviews = async () => {
            if (!movie?.title || !movie?.year) return;

            try {
                const res = await fetch(`http://localhost:5000/api/Review/GetByMovieTitleAndYear?title=${movie?.title}&year=${movie?.year}`);
                const json = await res.json();
                setReviews(json.result);
            } catch (err) {
                console.error("Error loading reviews:", err);
            }
        };

        fetchReviews();
    }, [movie?.title, movie?.year]);

    const handleSubmitReview = async () => {
        const token = localStorage.getItem("token");
        if (!token) return alert("You must be logged in to add a review!");

        try {
            const res = await fetch(`http://localhost:5000/api/Review/Add`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`,
                },
                body: JSON.stringify({
                    movieId: movie?.id,
                    content: reviewText,
                    rating: reviewRating,
                }),
            });

            if (res.ok) {
                alert("Review added!");
                setReviewText("");
                setReviewRating(1);
                // Reload reviews
                const json = await res.json();
                setReviews([...reviews, { id: json.result.id, content: reviewText, rating: reviewRating, userId: "" }]);
            } else {
                const json = await res.json();
                console.error("Backend error:", json);
                throw new Error(json?.error?.message || "Unexpected error");
            }
        } catch (err) {
            console.error(err);
            alert("Error submitting review");
        }
    };

    if (loading) return <p className="text-center text-white">Loading…</p>;
    if (!movie) return <p className="text-center text-white">Movie not found.</p>;

    return (
        <div className="container text-white py-4">
            <div className="row">
                <div className="col-md-4">
                    <img
                        src={movie.posterUrl ?? "https://via.placeholder.com/300x450?text=No+Image"}
                        alt={movie.title}
                        className="img-fluid rounded shadow"
                    />
                </div>
                <div className="col-md-8">
                    <h2>{movie.title}</h2>
                    <p><strong>Year:</strong> {movie.year ?? "—"}</p>
                    <p><strong>Genres:</strong> {movie.genres.join(", ")}</p>
                    <p><strong>Rating:</strong> ⭐ {movie.averageRating.toFixed(1)}</p>
                    <p><strong>Description:</strong> {movie.description}</p>

                    <h3 className="mt-4">Reviews</h3>
                    {reviews.length === 0 && <p>No reviews yet.</p>}
                    {reviews.map((rev) => (
                        <div key={rev.id} className="mb-2">
                            <strong>⭐ {rev.rating}</strong> - {rev.content}
                        </div>
                    ))}

                    <h4 className="mt-4">Add a Review</h4>
                    <textarea
                        className="form-control mb-2"
                        value={reviewText}
                        onChange={(e) => setReviewText(e.target.value)}
                        placeholder="Write your review"
                    />
                    <input
                        type="number"
                        className="form-control mb-2"
                        value={reviewRating}
                        min={1}
                        max={10}
                        onChange={(e) => setReviewRating(parseInt(e.target.value))}
                    />
                    <button className="btn btn-success" onClick={handleSubmitReview}>Add Review</button>
                </div>
            </div>
        </div>
    );
};

export default MovieDetails;
