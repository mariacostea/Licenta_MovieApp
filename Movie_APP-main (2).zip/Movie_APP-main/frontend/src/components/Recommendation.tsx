﻿import React from 'react';

const Recommendation: React.FC = () => {
    return (
        <div>
            <h2>⭐ Recommendation Page</h2>
            <p>This is the Feed section.</p>
        </div>
    );
};

export default Recommendation;
