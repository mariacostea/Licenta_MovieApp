﻿using Ardalis.Specification;
using MobyLabWebProgramming.Core.DataTransferObjects;
using MobyLabWebProgramming.Core.Entities;

public sealed class UsersWithoutFriendshipSpec : Specification<User, UserDTO>
{
    public UsersWithoutFriendshipSpec(Guid currentUserId, IEnumerable<Guid> relatedUserIds)
    {
        Query
            .Where(u => u.Id != currentUserId && !relatedUserIds.Contains(u.Id));
        Query    
            .Select(u => new UserDTO
            {
                Id = u.Id,
                Email = u.Email,
                Name = u.Name,
                Role = u.Role
            });
    }
}