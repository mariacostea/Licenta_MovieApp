﻿namespace MobyLabWebProgramming.Core.Specifications;

public class NotificationSpec
{
    
}