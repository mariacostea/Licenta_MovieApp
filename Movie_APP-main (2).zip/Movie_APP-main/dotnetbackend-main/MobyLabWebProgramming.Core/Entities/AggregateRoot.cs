﻿using Ardalis.Specification;

namespace MobyLabWebProgramming.Core.Entities;

public abstract class AggregateRoot : BaseEntity{ }