﻿namespace MobyLabWebProgramming.Core.DataTransferObjects;

public class FriendshipRequestCreateDTO
{
    public Guid ToUserId { get; set; }
}