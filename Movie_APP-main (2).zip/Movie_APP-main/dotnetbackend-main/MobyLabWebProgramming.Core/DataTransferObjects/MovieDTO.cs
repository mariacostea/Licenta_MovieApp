﻿namespace MobyLabWebProgramming.Core.DataTransferObjects;

public class MovieDTO
{
    public string Title { get; set; } = null!;
    public int? Year { get; set; }
}
