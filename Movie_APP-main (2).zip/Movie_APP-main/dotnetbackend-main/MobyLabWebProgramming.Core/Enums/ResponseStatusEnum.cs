﻿namespace MobyLabWebProgramming.Core.Enums;

public enum ResponseStatusEnum
{
    Ok,
    NotFound,
    Unauthorized,
    Error
}
