﻿namespace MobyLabWebProgramming.Core.Entities;

public enum FriendshipStatus
{
    Pending,    
    Accepted,   
    Rejected    
}