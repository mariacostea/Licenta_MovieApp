﻿using Ardalis.Specification;
using MobyLabWebProgramming.Core.Entities;

namespace MobyLabWebProgramming.Core.Specifications;

public class FriendsEventSpec : Specification<Event>
{
    public FriendsEventSpec(Guid currentUserId, IEnumerable<Guid> friendIds)
    {
        Query
            .Where(e => friendIds.Contains(e.OrganizerId))
            .Include(e => e.Movie)
            .Include(e => e.Organizer)
            .OrderByDescending(e => e.CreatedAt);
    }
}