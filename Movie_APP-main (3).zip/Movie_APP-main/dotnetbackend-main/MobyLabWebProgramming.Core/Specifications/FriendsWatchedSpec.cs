﻿using Ardalis.Specification;
using MobyLabWebProgramming.Core.Entities;

namespace MobyLabWebProgramming.Core.Specifications;

public class FriendsWatchedSpec : Specification<UserMovie>
{
    public FriendsWatchedSpec(Guid currentUserId)
    {
        Query
            .Where(um => um.IsWatched &&
                         um.User.Friendships.Any(f =>
                             f.Status == FriendshipStatus.Accepted &&
                             (f.AddresseeId == currentUserId || f.RequesterId == currentUserId)
                         )
            )
            .Include(um => um.Movie)
            .Include(um => um.User);
    }
}