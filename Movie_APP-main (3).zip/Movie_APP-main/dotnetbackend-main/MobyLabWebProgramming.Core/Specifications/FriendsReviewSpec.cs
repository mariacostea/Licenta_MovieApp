﻿using Ardalis.Specification;
using MobyLabWebProgramming.Core.Entities;

namespace MobyLabWebProgramming.Core.Specifications;

public class FriendsReviewSpec : Specification<Review>
{
    public FriendsReviewSpec(Guid currentUserId)
    {
        Query
            .Include(r => r.Movie)
            .Include(r => r.User)
            .Where(r => r.User.Friendships
                .Any(f =>
                    f.Status == FriendshipStatus.Accepted &&
                    (f.AddresseeId == currentUserId || f.RequesterId == currentUserId)
                ));
    }
}