﻿namespace MobyLabWebProgramming.Core.DataTransferObjects;

public class MovieTitleDTO
{
    public string Title { get; set; } = null!;
}